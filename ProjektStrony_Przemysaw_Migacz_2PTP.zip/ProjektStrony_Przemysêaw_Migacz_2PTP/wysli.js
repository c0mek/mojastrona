function wysli()
{
    alert("dziekujemy za zgłoszenie");
}